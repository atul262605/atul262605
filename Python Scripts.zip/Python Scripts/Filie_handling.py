# -*- coding: utf-8 -*-
"""
Created on Sat May  4 08:22:35 2024

@author: AtulSwati
"""

print("File IO")