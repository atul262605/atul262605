# -*- coding: utf-8 -*-
"""
Created on Mon May  6 09:36:39 2024

@author: AtulSwati
"""

print("hello world !!!")